package Assited_Practice_8;

// Base class: Animal
class Animal {
    public void sound() {
        System.out.println("Animal makes a sound.");
    }
}

// Derived class: Dog
class Dog extends Animal {
    @Override
    public void sound() {
        System.out.println("Dog barks.");
    }
}

// Derived class: Cat
class Cat extends Animal {
    @Override
    public void sound() {
        System.out.println("Cat meows.");
    }
}

public class polymorphismdemo {
    public static void main(String[] args) {
        // Creating objects of different types
        Animal animal = new Animal();
        Dog dog = new Dog();
        Cat cat = new Cat();

        // Polymorphic behavior
        Animal animal1 = dog;
        Animal animal2 = cat;

        // Calling overridden method
        animal.sound();     // Output: Animal makes a sound.
        dog.sound();        // Output: Dog barks.
        cat.sound();        // Output: Cat meows.

        // Polymorphic method calls
        animal1.sound();    // Output: Dog barks.
        animal2.sound();    // Output: Cat meows.
}

}

package Assisted_Practice_2;

class SleepDemo extends Thread {
    public void run() {
        System.out.println("Program started");
        try {
            // Sleep for 3 seconds
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Program resumed");
    }
}

public class sleep {
    public static void main(String[] args) {
        SleepDemo ob = new SleepDemo();
        ob.start();
    }
}

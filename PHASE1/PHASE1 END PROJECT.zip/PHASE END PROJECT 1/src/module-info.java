/**
 * 
 */
/**
 * 
 */
module CameraRentalApp {
}
package com.camerarental;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class HelpDisk {
	LoginManager loginManager = new LoginManager();
	CameraRentalApp app = new CameraRentalApp();

	public void Q_display() {
		boolean Quz = false;
				List<String> Querys = new ArrayList<String>();
				do {
					System.out.println("1. GET LIST OF CAMARA ?");
					System.out.println("2. HOW TO BOOK A CAMARA ?");
					System.out.println("3. NEDD ADMIN CONTACT DETAILS !! ");
					System.out.println("4. HOW TO CHECK WALLET BALANCE ?");
					System.out.println("5. COUSTM QUESTIONS");
					System.out.println("6. EXIT");
					@SuppressWarnings("resource")
					Scanner sc = new Scanner(System.in);
						int choice = sc.nextInt();
						switch (choice) {
						case 1:
							System.out.println("GO TO THE  MY_CAMARA IN MAIN MANU AND SELECT OPITON 3 NOW WE SEE LIST OF CAMARAS: ");
							break;
						case 2:
							System.out.println("GO TO MAIN MANU AND SELECT OPTION 2. RENT A CAMERA");
							break;
						case 3:
							System.out.println("Name: ABCD CameraRental\n Contact:9876543210");
							break;
						case 4: 
							System.out.println("Go to main manu and select option 3. WalletBalance");
							break;
						case 5:
							System.out.println("Enter your query: ");
							String Query=sc.toString();
							Querys.add(Query);
							System.out.println(Querys.toString());
							break;
						case 6:
							Quz = true;
							System.out.println("BACK TO MAIN MENU!");
							break;
						default:
							System.out.println("INVALID CHOICE!");
						}			
		}while(!Quz);
	}
}	

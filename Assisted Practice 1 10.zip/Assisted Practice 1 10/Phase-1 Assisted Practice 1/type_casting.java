package phase1.com;

public class type_casting {

		public static void main(String[] args) {
			System.out.println("implicit type casting");
			//implicit type casting
			byte input=18;										//8 bits
			System.out.println("Value of input: "+input);
			
			short input1=input;									//16 bits
			System.out.println("Value of input1: "+input1);
			
			//char input2=input1;									//16 bit (unsinged)
			//System.out.println("Value of input2: "+input2);
			
			char input3='M';
			System.out.println("Value of input3: "+input3);
			
			int number=input3;										//32 bits {return ascii values}
			System.out.println("Value of number: "+number);
			
			int  number0=3;
			long number1=number0;
			System.out.println("Value of number1: "+number1);		//64 bit
			
			float number2=number1;
			System.out.println("Value of number2: "+number2);		//32 {return in decimal value}
			
			double number3=number2;
			System.out.println("Value of number3: "+number3+" \n");        //64 {return decimal values along with 16 digits}
			
			//explicit conversion
			System.out.println("Explicit Type Casting");
			double point=3.14d;
			System.out.println("Value of point: "+point);
			int point1=(int)point;
			System.out.println("Value of point1: "+point1);
				}
	}
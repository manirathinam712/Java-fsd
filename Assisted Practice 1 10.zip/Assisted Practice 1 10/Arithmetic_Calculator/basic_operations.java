package basic_arithmetic;
import java.util.Scanner;

public class basic_operations {

public static void main(String[] args) {

 double num1, num2;
 char operator;

 Scanner sc = new Scanner(System.in);

 System.out.println("Enter the first number:");
 num1 = sc.nextDouble();

 System.out.println("Enter the second number:");
 num2 = sc.nextDouble();

 System.out.println("Enter the operator (+, -, *, /):");
 operator = sc.next().charAt(0);

 double result = 0;

 switch (operator) {
   case '+':
     // addition
     result = num1 + num2;
     break;
   case '-':
     // subtraction
     result = num1 - num2;
     break;
   case '*':
     // multiplication
     result = num1 * num2;
     break;
   case '/':
     // division
     result = num1 / num2;
     break;
   default:
     // display an error message for invalid operator
     System.out.println("Invalid operator!");
     return;
 }

 System.out.println("The result is: " + result);

 sc.close();
}
}
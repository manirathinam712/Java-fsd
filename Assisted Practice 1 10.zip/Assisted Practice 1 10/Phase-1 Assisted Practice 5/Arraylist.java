package collections.com;

import java.util.ArrayList;

public class Arraylist {
	public static void main(String[] args) {
        // ArrayList Example
        ArrayList<String> list = new ArrayList<>();
        list.add("apple");
        list.add("banana");
        list.add("cherry");
        System.out.println("ArrayList: " + list);

}
}
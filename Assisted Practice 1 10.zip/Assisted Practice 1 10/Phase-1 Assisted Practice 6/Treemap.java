package maps;

import java.util.*;
public class Treemap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMap<Integer, String> tm=new TreeMap<Integer, String>();
		tm.put(3, "a");
		tm.put(2, "b");
		tm.put(1, "c");
		System.out.println(tm);

	}

}

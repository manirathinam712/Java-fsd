package Email_validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;
public class emailvalidation {
public static void main(String[] args) {
Scanner input = new Scanner(System.in);
System.out.print("Enter an email address: ");
String email = input.nextLine();
if (isValidEmail(email)) {
System.out.println("	");
} else {
System.out.println("Invalid email address.");
}
}
public static boolean isValidEmail(String email) {
String emailPattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
Pattern pattern = Pattern.compile(emailPattern);
Matcher matcher = pattern.matcher(email);
return matcher.matches();
}
}
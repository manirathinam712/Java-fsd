package Access_modifiers1;
import Access_modifiers.Publicspecifier;

public class Publicspecifier1 {

	public static void main(String[] args) {
		Publicspecifier input=new Publicspecifier();
		
        // Accessing a public variable
		input.Publicvalue=25;
		System.out.println("THE PUBLICVALUE IS: "+input.Publicvalue);
		
		input.Publicmethod();

	}

}

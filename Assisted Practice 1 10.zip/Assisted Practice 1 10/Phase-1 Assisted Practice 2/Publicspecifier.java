package Access_modifiers;

public class Publicspecifier {

		public int Publicvalue;
		
		public void Publicmethod() {
			System.out.println("This is a PUBLIC method");
		}

	}


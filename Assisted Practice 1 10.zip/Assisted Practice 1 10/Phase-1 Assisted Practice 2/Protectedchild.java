package Access_modifiers1;
import Access_modifiers.*;

public class Protectedchild extends ProtectedParent {
	public static void main(String[] args) {
		Protectedchild obj = new Protectedchild();   
	       obj.display();  
	}
	
}
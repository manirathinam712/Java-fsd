package Access_modifiers;

class MyClass {
	  int x; 											// default access modifier
	  
	  void Display() {								 	// default access modifier
	    System.out.println("x = " + x);
	  }
	}

	public class Defaultmodifier {
	  public static void main(String[] args) {
	    MyClass x_value = new MyClass();
	    x_value.x = 5; 										// accessible within the same package
	    x_value.Display(); 									// accessible within the same package
	  }
	}
